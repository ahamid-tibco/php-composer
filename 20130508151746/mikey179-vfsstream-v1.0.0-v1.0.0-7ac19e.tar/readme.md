For more information have a look in the [wiki](https://github.com/mikey179/vfsStream/wiki).

[![Build Status](https://secure.travis-ci.org/mikey179/vfsStream.png)](http://travis-ci.org/mikey179/vfsStream)