<?php

header('location: /redirect_destination.php');
