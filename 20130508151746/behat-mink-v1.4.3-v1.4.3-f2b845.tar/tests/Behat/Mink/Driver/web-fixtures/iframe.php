<html>
<body>

<iframe src="iframe_inner.php" name="subframe"></iframe>

<div id="text">
    Main window div text
</div>

</body>
</html>
