<?php

echo json_encode(array(
    'key1' => 'val1',
    'key2' => 234,
    'key3' => array(1, 2, 3)
));
