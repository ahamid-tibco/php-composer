<?php
class Struct
{
    public $var;

    public function __construct($var)
    {
        $this->var = $var;
    }
}
