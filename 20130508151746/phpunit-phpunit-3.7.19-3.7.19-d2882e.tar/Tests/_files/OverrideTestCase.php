<?php
require_once 'OneTestCase.php';

class OverrideTestCase extends OneTestCase
{
    public function testCase($arg = '')
    {
    }
}
