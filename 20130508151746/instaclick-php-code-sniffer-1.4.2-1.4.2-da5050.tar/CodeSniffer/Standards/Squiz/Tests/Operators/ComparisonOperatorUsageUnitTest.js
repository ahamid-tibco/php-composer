if (value === TRUE) {
} else if (value === FALSE) {
}

if (value == TRUE) {
} else if (value == FALSE) {
}

if (value) {
} else if (!value) {
}

if (value.isSomething === TRUE) {
} else if (myFunction(value) === FALSE) {
}

if (value.isSomething == TRUE) {
} else if (myFunction(value) == FALSE) {
}

if (value.isSomething) {
} else if (!myFunction(value)) {
}

if (value === TRUE || other === FALSE) {
}

if (value == TRUE || other == FALSE) {
}

if (value || !other) {
}

if (one === TRUE || two === TRUE || three === FALSE || four === TRUE) {
}

if (one || two || !three || four) {
}
