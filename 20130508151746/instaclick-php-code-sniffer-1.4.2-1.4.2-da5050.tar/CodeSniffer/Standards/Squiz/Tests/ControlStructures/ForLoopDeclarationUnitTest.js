// Valid.
for (var i = 0; i < 10; i++) {
}

// Invalid.
for ( i = 0; i < 10; i++ ) {
}

for (i = 0;  i < 10;  i++) {
}

for (var i = 0 ; i < 10 ; i++) {
}

for (i = 0;i < 10;i++) {
}

// The works.
for ( var i = 0 ;  i < 10 ;  i++ ) {
}

this.formats = {};
dfx.inherits('ContentFormat', 'Widget');

for (var widgetid in this.loadedContents) {
    if (dfx.isset(widget) === true) {
        widget.loadAutoSaveCWidgetStore.setData('activeScreen', null);widget.getContents(this.loadedContents[widgetid], function() {self.widgetLoaded(widget.id);});
    }
}

for (var i = 0; i < 10;) {
}
for (var i = 0; i < 10; ) {
}
