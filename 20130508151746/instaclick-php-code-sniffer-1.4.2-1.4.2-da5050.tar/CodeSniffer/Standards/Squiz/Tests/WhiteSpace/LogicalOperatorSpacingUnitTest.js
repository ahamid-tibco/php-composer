

if (foo || bar) {}
if (foo||bar && baz) {}
if (foo|| bar&&baz) {}
if (foo  ||   bar   && baz) {}

if (foo ||
    bar
    && baz
) {
}

if (foo||
    bar
    &&baz
) {
}
