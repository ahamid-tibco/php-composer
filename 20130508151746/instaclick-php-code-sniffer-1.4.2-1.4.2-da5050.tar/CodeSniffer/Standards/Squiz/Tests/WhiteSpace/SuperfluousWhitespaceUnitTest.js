
alert('hi');
alert('hello');   
    
if (something) {  
    
}


function myFunction()
{
    alert('code here');

    alert('code here');


    // Hello.

    /*
        HI
    */


}

function myFunction2()
{
    alert('code here');


    alert('code here');

}

// @codingStandardsChangeSetting Squiz.WhiteSpace.SuperfluousWhitespace ignoreBlankLines true

function myFunction2()
{
    alert('code here');
    
    alert('code here');
    
}

// @codingStandardsChangeSetting Squiz.WhiteSpace.SuperfluousWhitespace ignoreBlankLines false


