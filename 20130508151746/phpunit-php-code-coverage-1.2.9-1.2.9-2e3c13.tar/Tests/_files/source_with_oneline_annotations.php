<?php

/** Docblock */
interface Foo {
    public function bar();
}

class Foo
{
    public function bar()
    {
    }
}
