<?php
/**
 * @SuppressWarnings(PHPMD)
 */
class testApplyNotInvokesRuleWhenSuppressAnnotationExists
{
    
}
