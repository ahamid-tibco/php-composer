<?php
class testRuleAppliesToMultipleMethodUnusedFormalParameter
{
    public function testRuleAppliesToMultipleMethodUnusedFormalParameter($x, $y)
    {
        return $z;
    }
}