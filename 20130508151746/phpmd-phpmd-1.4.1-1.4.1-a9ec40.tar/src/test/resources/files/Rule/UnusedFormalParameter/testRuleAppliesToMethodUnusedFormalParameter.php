<?php
class testRuleAppliesToMethodUnusedFormalParameter
{
    public function testRuleAppliesToMethodUnusedFormalParameter($x)
    {
        
    }
}
