<?php
interface testRuleDoesNotApplyToInterfaceMethodFormalParameter
{
    function testRuleDoesNotApplyToInterfaceMethodFormalParameter($x, $y, $z);
}