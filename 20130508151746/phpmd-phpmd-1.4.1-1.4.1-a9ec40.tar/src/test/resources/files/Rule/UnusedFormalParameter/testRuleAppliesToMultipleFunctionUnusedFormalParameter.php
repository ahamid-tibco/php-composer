<?php
function testRuleAppliesToMultipleFunctionUnusedFormalParameter($x, $y, $z)
{
    return $foobar;
}
