<?php
class testRuleAppliesToMethodWithExitExpression
{
    protected function testRuleAppliesToMethodWithExitExpression()
    {
        exit(0);
    }
}