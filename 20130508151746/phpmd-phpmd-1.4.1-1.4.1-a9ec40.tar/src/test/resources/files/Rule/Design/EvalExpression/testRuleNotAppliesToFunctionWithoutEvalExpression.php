<?php
function testRuleNotAppliesToFunctionWithoutEvalExpression()
{
    echo __FUNCTION__;
}