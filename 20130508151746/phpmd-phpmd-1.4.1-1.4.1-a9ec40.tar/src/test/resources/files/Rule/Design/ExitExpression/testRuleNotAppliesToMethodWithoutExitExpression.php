<?php
class testRuleNotAppliesToMethodWithoutExitExpression
{
    public function testRuleNotAppliesToMethodWithoutExitExpression()
    {
        echo __METHOD__;
    }
}