<?php
class testRuleNotAppliesToMethodWithoutEvalExpression
{
    public function testRuleNotAppliesToMethodWithoutEvalExpression()
    {
        echo __METHOD__;
    }
}