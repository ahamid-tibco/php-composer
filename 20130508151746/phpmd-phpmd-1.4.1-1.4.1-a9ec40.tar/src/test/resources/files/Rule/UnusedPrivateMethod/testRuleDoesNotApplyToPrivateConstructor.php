<?php
class testRuleDoesNotApplyToPrivateConstructor
{
    private function __construct()
    {
        
    }
}