<?php
class testRuleAppliesToUnusedPrivateMethod
{
    private function foo()
    {
        
    }
}