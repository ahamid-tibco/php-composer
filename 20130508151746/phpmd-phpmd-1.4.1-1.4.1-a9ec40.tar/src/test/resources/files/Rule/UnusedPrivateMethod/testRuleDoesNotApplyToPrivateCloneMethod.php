<?php
class testRuleDoesNotApplyToPrivateCloneMethod
{
    private function  __clone()
    {

    }
}