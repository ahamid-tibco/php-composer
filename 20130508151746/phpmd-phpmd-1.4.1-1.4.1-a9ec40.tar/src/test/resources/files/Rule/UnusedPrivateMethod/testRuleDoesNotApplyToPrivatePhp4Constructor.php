<?php
class testRuleDoesNotApplyToPrivatePhp4Constructor
{
    private function testRuleDoesNotApplyToPrivatePhp4Constructor()
    {
        
    }
}