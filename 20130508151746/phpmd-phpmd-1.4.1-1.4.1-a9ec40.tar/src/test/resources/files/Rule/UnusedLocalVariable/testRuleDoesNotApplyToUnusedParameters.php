<?php
class testRuleDoesNotApplyToUnusedParameters
{
    function testRuleDoesNotApplyToUnusedParameters($x, $y, $z)
    {
        
    }
}