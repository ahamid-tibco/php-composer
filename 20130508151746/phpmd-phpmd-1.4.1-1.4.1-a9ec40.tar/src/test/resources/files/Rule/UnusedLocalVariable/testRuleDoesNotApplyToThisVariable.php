<?php
class testRuleDoesNotApplyToThisVariable
{
    public function testRuleDoesNotApplyToThisVariable()
    {
        $this->foo;
    }
}