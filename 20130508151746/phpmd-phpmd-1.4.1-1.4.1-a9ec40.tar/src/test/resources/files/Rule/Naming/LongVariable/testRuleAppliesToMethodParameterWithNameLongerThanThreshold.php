<?php
class testRuleAppliesToMethodParameterWithNameLongerThanThreshold
{
    function testRuleAppliesToMethodParameterWithNameLongerThanThreshold($thisIsLongMethodParameterName)
    {
        
    }
}