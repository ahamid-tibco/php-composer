<?php
class testRuleNotAppliesToFieldWithNameEqualToThreshold
{
    private $fooBar;
}