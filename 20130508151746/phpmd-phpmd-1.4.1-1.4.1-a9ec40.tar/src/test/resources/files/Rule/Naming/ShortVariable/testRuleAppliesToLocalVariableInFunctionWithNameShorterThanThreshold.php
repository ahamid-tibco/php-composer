<?php
function testRuleAppliesToLocalVariableInFunctionWithNameShorterThanThreshold()
{
    $xy = 42;
}