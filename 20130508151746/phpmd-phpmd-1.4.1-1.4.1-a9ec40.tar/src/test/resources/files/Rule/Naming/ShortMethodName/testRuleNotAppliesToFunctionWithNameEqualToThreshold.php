<?php
function testRuleNotAppliesToFunctionWithNameEqualToThreshold()
{
    
}