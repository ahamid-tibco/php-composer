<?php
interface testRuleNotAppliesToInterfaceConstantWithUpperCaseCharacters
{
    const T_FOO = 42;

    const T_BAR = 23;

    const T_BAZ = 17;
}