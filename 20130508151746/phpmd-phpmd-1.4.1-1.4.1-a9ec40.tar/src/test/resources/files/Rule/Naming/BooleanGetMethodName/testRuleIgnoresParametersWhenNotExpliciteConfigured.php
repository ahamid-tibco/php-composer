<?php
class testRuleIgnoresParametersWhenNotExpliciteConfigured
{
    /**
     * @return boolean
     */
    function getBaz($foo) {}
}