<?php
class testRuleAppliesToLocalVariableInMethodWithNameShorterThanThreshold
{
    function testRuleAppliesToLocalVariableInMethodWithNameShorterThanThreshold()
    {
        $fo = 42;
    }
}