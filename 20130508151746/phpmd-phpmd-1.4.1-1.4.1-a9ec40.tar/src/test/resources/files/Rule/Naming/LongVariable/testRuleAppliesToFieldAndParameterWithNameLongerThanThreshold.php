<?php
class testRuleAppliesToFieldAndParameterWithNameLongerThanThreshold
{
    protected $_foo;

    protected function testRuleAppliesToFieldAndParameterWithNameLongerThanThreshold($fooB)
    {
        
    }
}