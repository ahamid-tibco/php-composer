<?php
class testRuleAppliesToFieldWithNameShorterThanThreshold
{
    private $fo = 0;
}