<?php
class testRuleNotAppliesToLocalVariableInMethodWithNameEqualToThreshold
{
    function testRuleNotAppliesToLocalVariableInMethodWithNameEqualToThreshold()
    {
        $foo = 42;
    }
}