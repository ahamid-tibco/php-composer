<?php
function testRuleNotAppliesToFunctionParameterWithNameLongerThanThreshold($fooBar)
{
    
}