<?php
function testRuleNotAppliesToFunctionParameterWithNameSmallerThanThreshold($fooBar)
{
    
}