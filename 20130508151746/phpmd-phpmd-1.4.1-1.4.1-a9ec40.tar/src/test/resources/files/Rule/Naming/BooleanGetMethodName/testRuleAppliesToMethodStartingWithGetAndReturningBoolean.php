<?php
class testRuleAppliesToMethodStartingWithGetAndReturningBoolean
{
    /**
     * @return boolean
     */
    public function getFooBar()
    {

    }
}