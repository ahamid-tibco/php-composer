<?php
function testRuleAppliesToFunctionParameterWithNameLongerThanThreshold($thisIsAReallyLongParameterName)
{
    
}