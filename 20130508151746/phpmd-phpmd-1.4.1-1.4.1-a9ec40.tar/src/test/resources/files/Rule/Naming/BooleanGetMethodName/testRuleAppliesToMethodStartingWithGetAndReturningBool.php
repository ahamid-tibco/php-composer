<?php
class testRuleAppliesToMethodStartingWithGetAndReturningBool
{
    /**
     * @return Bool
     */
    public function getBaz() {}
}