<?php
class testruleappliestoconstructormethodnamedasenclosingclasscaseinsensitive
{
    function testRuleAppliesToConstructorMethodNamedAsEnclosingClassCaseInsensitive()
    {
        
    }
}