<?php
function testRuleNotAppliesToFunctionWithNameLongerThanThreshold()
{

}