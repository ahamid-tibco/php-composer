<?php
class testRuleNotAppliesToMethodParameterWithNameShorterThanThreshold
{
    function testRuleNotAppliesToMethodParameterWithNameShorterThanThreshold($fooBar)
    {
        
    }
}