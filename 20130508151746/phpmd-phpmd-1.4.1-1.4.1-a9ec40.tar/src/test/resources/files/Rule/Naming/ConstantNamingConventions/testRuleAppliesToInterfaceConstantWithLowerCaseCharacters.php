<?php
interface testRuleAppliesToInterfaceConstantWithLowerCaseCharacters
{
    const t_foo = 42, t_bar = 23, t_baz = 17;
}