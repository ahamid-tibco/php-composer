<?php
class testRuleAppliesToMethodParameterWithNameShorterThanThreshold
{
    public function testRuleAppliesToMethodParameterWithNameShorterThanThreshold($fo) {}
}