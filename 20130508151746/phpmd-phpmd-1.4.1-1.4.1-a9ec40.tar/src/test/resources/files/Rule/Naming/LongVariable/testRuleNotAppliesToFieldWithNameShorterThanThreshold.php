<?php
class testRuleNotAppliesToFieldWithNameShorterThanThreshold
{
    private $fooBar = 0;
}
