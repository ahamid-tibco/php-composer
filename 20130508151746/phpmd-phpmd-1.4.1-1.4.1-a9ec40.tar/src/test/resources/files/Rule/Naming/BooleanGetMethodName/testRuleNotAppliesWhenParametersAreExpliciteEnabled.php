<?php
class testRuleNotAppliesWhenParametersAreExpliciteEnabled
{
    /**
     * @return boolean
     */
    public function getBaz($foo) {}
}