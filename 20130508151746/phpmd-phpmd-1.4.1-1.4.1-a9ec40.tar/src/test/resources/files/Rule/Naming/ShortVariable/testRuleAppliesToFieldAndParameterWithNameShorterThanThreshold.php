<?php
class testRuleAppliesToFieldAndParameterWithNameShorterThanThreshold
{
    protected $_x;

    public function testRuleAppliesToFieldAndParameterWithNameShorterThanThreshold($x) {}
}
