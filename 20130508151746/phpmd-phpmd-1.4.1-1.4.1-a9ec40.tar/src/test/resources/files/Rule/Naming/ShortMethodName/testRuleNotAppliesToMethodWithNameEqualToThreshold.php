<?php
class testRuleNotAppliesToMethodWithNameEqualToThreshold
{
    function testRuleNotAppliesToMethodWithNameEqualToThreshold()
    {
        
    }
}