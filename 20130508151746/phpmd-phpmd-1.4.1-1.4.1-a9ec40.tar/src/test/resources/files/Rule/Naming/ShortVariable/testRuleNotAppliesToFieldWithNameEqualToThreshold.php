<?php
class testRuleNotAppliesToFieldWithNameEqualToThreshold
{
    private $foo = 42;
}