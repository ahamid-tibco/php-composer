<?php
class testRuleAppliesToUnusedPrivateStaticField
{
    private static $_foo;
}