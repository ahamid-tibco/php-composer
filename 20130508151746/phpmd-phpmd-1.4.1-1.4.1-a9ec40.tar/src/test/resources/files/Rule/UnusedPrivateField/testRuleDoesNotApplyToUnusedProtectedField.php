<?php
class testRuleDoesNotApplyToUnusedProtectedField
{
    protected $foo = 23;
}