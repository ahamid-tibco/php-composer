<?php
class Class3 {
    public function bar()
    {
        $bar = 23;
    }
}