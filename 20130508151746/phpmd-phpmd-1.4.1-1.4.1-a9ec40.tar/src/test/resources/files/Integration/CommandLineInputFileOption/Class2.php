<?php
class Class2 {
    function foo($foo) {
        return ($foo * 42);
    }
}