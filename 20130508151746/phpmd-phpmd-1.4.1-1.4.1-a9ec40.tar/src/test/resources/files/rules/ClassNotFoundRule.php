<?php
// Nothing, no class :-) 
?>
