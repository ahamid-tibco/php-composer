<?php
class testIsDeclarationReturnsTrueForMethodDeclarationClass
{
    public function testIsDeclarationReturnsTrueForMethodDeclaration($foo)
    {

    }
}
