<?php
class testGetParentTypeReturnsClassForClassMethodClass
{
    public function testGetParentTypeReturnsClassForClassMethod()
    {
        
    }
}
class testGetParentTypeReturnsClassForClassMethodClass
{
    public function testGetParentTypeReturnsClassForClassMethod()
    {
        
    }
}
