<?php
class testIsDeclarationReturnsTrueForMethodDeclarationWithParentClass
    extends testIsDeclarationReturnsTrueForMethodDeclarationWithParentParentClass
{
    public function testIsDeclarationReturnsTrueForMethodDeclarationWithParent($foo)
    {

    }
}

class testIsDeclarationReturnsTrueForMethodDeclarationWithParentParentClass
{
    public function testIsDeclarationReturnsTrueForMethodDeclaration($foo)
    {

    }
}
