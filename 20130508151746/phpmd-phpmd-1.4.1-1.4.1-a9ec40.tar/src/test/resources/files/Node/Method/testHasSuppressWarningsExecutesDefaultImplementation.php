<?php
class testHasSuppressWarningsExecutesDefaultImplementationClass
{
    /**
     * @SuppressWarnings("PHPMD.FooBar")
     */
    function testHasSuppressWarningsExecutesDefaultImplementation()
    {

    }
}

class testHasSuppressWarningsExecutesDefaultImplementationClass
{
    /**
     * @SuppressWarnings("PHPMD.FooBar")
     */
    function testHasSuppressWarningsExecutesDefaultImplementation()
    {

    }
}
