<?php
/**
 * Simple test class
 */
class NPathClass {
    function doSomething()
    {
        if (true) {}
        if (true) {}
        if (true) {}
        if (true) {}
        if (true && true && true && true) {}
        if (true && true && true && true) {}
        if (true && true && true && true) {}
        if (true && true && true && true) {}
        if (true && true && true && true) {}
    }
}

