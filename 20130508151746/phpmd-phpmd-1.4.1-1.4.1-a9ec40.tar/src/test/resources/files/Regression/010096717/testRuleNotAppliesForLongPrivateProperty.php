<?php
class testRuleNotAppliesForLongPrivateProperty
{
    private $testRuleNotAppliesForLongPrivateProperty = 42;
}