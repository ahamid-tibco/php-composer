========
Releases
========

The following releases of PHPMD are available for download

.. include:: ../release/parts/latest.rst

