<?php
require_once 'PHPUnit/Extensions/SeleniumTestCase.php';

class SeleneseTest extends Tests_SeleniumTestCase_BaseTestCase
{
    public static $seleneseDirectory = './selenium-1-tests/selenese/';
}
