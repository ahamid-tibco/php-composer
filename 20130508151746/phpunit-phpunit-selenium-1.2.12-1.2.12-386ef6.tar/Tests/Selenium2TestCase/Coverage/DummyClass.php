<?php
class DummyClass
{
    public function coveredMethod()
    {
        return null;
    }

    public function uncoveredMethod()
    {
        return null;
    }
}
