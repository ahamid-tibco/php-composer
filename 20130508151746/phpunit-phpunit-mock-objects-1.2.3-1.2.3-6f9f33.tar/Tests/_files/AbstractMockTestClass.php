<?php
abstract class AbstractMockTestClass
{
    abstract public function doSomething();
}
