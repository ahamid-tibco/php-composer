<?php

namespace Container14;

use Symfony\Component\DependencyInjection\ContainerBuilder;

class ProjectServiceContainer extends ContainerBuilder
{
}

return new ProjectServiceContainer();
