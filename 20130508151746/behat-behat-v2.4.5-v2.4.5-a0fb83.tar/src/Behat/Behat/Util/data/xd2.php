<?php
$UTF8_TO_ASCII[0xd2] = array(

);
