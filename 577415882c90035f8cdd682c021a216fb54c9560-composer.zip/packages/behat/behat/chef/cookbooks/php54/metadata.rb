recipe "php54::default", "Adds PHP5.4 repository to APT"
