<!-- widop.com/test.html -->
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <title>Index page</title>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
</head>
<body>

<form action="#">
    <p>
        <label for="phone">Téléphone</label>
        <input type="text" name="phone" id="phone" />
    </p>
    <p>
        <label for="daphone">DaPhone</label>
        <input type="text" name="daphone" id="daphone" />
    </p>

    <input type="submit" value="Send" />
</form>

</body>
</html>
