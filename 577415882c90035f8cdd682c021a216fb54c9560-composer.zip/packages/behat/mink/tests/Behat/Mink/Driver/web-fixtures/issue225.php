<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
    "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr">
<head>
    <title>Index page</title>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
    <script src="js/jquery-1.6.2-min.js"></script>
</head>
<body>

<button id="btn">Créer un compte</button>

<div id="panel"></div>

<script type="text/javascript">
    $('#btn').click(function (event) {
        $('#panel').text('OH ' + 'AIH!');
    });
</script>
</body>
</html>
