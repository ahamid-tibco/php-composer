<html>
<body>

    <div id="text">
        iFrame div text
    </div>

</body>
</html>
