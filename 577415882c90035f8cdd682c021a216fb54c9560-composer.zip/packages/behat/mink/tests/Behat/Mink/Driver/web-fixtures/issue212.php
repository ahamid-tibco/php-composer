<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML+RDFa 1.0//EN"
  "http://www.w3.org/MarkUp/DTD/xhtml-rdfa-1.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<body>
  <form action="/" method="post" id="user-login-form">
    <input type="submit" name="toto" id="jaguar-button" value="jaguar"/>
    <input type="submit" name="toto" id="poney-button" value="poney"/>
  </form>
</body>
</html>
