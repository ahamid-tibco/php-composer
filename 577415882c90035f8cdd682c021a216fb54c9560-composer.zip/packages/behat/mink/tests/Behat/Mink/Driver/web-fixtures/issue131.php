<!DOCTYPE html>
<html lang="en">
<head>
    <title>Issue 131</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
</head>
<body>
    <h1>There is a non breaking&#160;space</h1>
    <pre id="foobar">Some accentués characters</pre>
    <form>
        <select name="foobar">
          <option value="1" type="text">Gimme some accentués characters</option>
        </select>
        <input type="submit" />
    </form>
</body>
</html>
